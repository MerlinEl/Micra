# ImageProcessing
Program in C# using Photoshop CS6 API 

This project is a basic overview on how interact with Photoshop through a C# program.

Required:
- Photoshop CS6 installed
- Photoshop CS6 API libraries


