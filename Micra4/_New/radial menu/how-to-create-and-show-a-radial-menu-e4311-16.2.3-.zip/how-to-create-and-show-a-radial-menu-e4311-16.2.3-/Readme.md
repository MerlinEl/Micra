<!-- default file list -->
*Files to look at*:

* [Form1.cs](./CS/CreateRadialMenu/Form1.cs) (VB: [Form1.vb](./VB/CreateRadialMenu/Form1.vb))
<!-- default file list end -->
# How to: Create and show a Radial Menu


<p>This example shows how to create a Radial Menu displaying a sub-menu, buttons and check buttons.</p>

<br/>


