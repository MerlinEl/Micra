LSCM UNWRAP - 3DSMAX 
=====================
v1.0

by Christoph 'CrazyButcher' Kubisch
http://crazybutcher.cube3d.de

LSCM-Based UV Unwrapping, Maxscript/Maxplugin combo
based on Blender3D/OpenNL


=====================
Future:

I might do a non-free version that encorporates a second unwrap
mode (ABF) and live lscm unwrapping, depending on popular
demand.

Feedback:
http://www.luxinia.de/forum/index.php?c=6


=====================
INSTALL:

copy stdplugs to your max folder
copy the proper plugin to your max/plugins folder
(e.g 3dsmax 2008 32 bit would use "LSCMUnwrap_9to2008-32.gup")

restart 3dsmax

execute scripts/CB_LSCMUnwrapper_install.ms ONCE
it will install the macroscript (you never need to do again)

Go to "Customize-> Customize User Interface"
you will then find the proper macroscripts in the
"CrazyButcher" category, and can assign them
freely to quad menus, toolbars or keybinds.


=====================
TROUBLESHOOTING:


32-BIT (Version 5.1, 6 or 7)
----------------------------

If you get the message that a plugin/dll failed to
initialize, then copy the msvc/msvcr71.dll into your 3dsmax
directory.
NEVER OVERWIRTE stuff! 
If it's already there and doesn't work, tell me.


64-BIT
------

The 64-Bit version is completely untested 
(I dont have xp64 or vista64 at the moment). 
If you get a .dll initialize error, then 
install the vc++ 2005 runtimes.

- x64 -
http://www.microsoft.com/downloads/info.aspx?na=22&p=4&SrcDisplayLang=en&SrcCategoryId=&SrcFamilyId=&u=%2fdownloads%2fdetails.aspx%3fFamilyID%3deb4ebe2d-33c0-4a47-9dd4-b9a6d7bd44da%26DisplayLang%3den


BOTH
----
If you get an error on maxscript on the start,
delete the cb_lscm.ini in your /plugcfg directory.

(note that max9 stores them in windows 
documents and settings/local settings/application data/autodesk/3dsmax...
or alike)

Max9 Note:
If the maxscript crashes with "System exception" or so
when you execute the lscm unwrap, "reset" max once
then it should work (reported workaround by Rom Impas)
This doesnt happen for me, I am not sure what the 
cause of it is,

=====================
USE:

Within editable poly modifier you select edges
and mark them as seams, either using the 
"LSCM Central" or the other macroscripts.
After that you run the UNWRAP in "LSCM Central"

=====================
No guarantees, use at your own risk


---------------------
ORIGINAL AUTHORS LSCM:

The blender3d implementation, this plugin
is heavily based on, was done by Brecht Van Lommel
and Jens Ole Wund
http://www.blender3d.org

As the blender3d version it uses OpenNL by 
Bruno Levy
http://www.loria.fr/~levy

---------------------
History:

1.0
* compiled for max 2009. 
bugfix: sometimes the unwrap edit window contained "broken" unwrap
but showed proper solution once closed and re-opened.

0.932
* sourcecode package now also for vc8 + 64-Bit version

0.931
* minor changes to sourcecode package

0.93
* displaying seams didnt refresh correctly in max > 5
  especially bad when not seeing the result of click mark/unmark
  in the LSCM central

0.925
* wrong plugins for max < 9 packaged

0.92
* scaling is now based on mesh area
* packmax width added so that user can define
  how wide the largest group should be in uvspace
* 3dsmax9-32 bit version of plugin


0.9: 
* rewrote how unwrapping result is stored
  (not modifying the baseobject anymore)
* pinning and onlyselected works much better
* scaling of result groups slightly changed 
* issue: the markers along the seams are not always visible

0.81:
* minor bugfix in the script

0.8: 
* vertex pinning and onlyselected added, not always working well

0.5:
* first version, modifies baseobject's uvw