Working example of sending data via MaxScript DotNet over TCP/IP socket.

From blog post:
	http://techarttiki.blogspot.com/2009/12/maxscript-dotnet-sockets-with-python.html

Thanks to all who posted in the "dotNet + MXS" thread on CGTalk.
	http://forums.cgsociety.org/showthread.php?f=98&t=551473
The info there put me on the right trail to making this work.

Adam Pletcher, Technical Art Director, Volition/THQ
	adam.pletcher@gmail.com
	http://techarttiki.blogspot.com
	http://www.volition-inc.com
	

Requirements ----

- Python
	www.python.org
- wxPython GUI extensions
	www.wxpython.org
- 3ds Max
	www.autodesk.com

	
Installation Instructions ----

1. Copy "setup_socket.ms" into your 3ds Max scripts\startup folder.  For example:
	D:\3ds Max 2010\scripts\startup
	
2. Start 3ds Max.  You should see a message in the MaxScript Listener indicating the
	socket callback was set up.
	
3. Run the included python script "python_listener.py"

4. As you change the object selection in 3ds Max, the python dialog will update to show
	the names of the selected objects.  If not, one of us screwed something up.  :)