//
// XMPUtils.jsx
//
// $Id: XMPUtils.jsx,v 1.2 2010/03/29 02:23:24 anonymous Exp $
// Copyright: (c)2007, xbytor
// License: http://www.opensource.org/licenses/bsd-license.php
// Contact: xbytor@gmail.com
//
//@show include
//

XMPUtils = function XMPUtils() {
};
XMPUtils.appendProperties = function(source, dest, options) {
  return undefined;
};
XMPUtils.catenateArrayItems = function(xmpObj, schemaNS, arrayName,
                                       separator, quotes, options) {
  return '';
};
XMPUtils.composeArrayItemPath = function(schemaNS, arrayName, itemIndex) {
  return '';
};
XMPUtils.composeFieldSelector = function(schemaNS, arrayName, fieldNS,
                                         fieldName, fieldValue) {
};
XMPUtils.composeLanguageSelector = function(schemaNS, arrayName, locale) {
};
XMPUtils.composeStructFieldPath = function(schemaNS, structName,
                                           fieldNS, fieldName) {
};
XMPUtils.composeQualifierPath = function(schemaNS, propName,
                                         qualNS, qualName) {
  return '';
};
XMPUtils.duplicateSubtree = function(source, dest, sourceNS,
                                     sourceRoot,destNS, destRoot, options) {
  return undefined;
};
XMPUtils.removeProperties = function(xmpObj, schemaNS, propName, options) {
  return undefined;
};
XMPUtils.separateArrayItems = function(xmpObj, schemaNS, arrayName,
                                       arrayOptions, concatString) {
  return undefined;
};
"XMPUtils.jsx";
// EOF
