//
// XMPScript.jsx
//
// $Id: XMPScript.jsx,v 1.2 2010/03/29 02:23:24 anonymous Exp $
// Copyright: (c)2007, xbytor
// License: http://www.opensource.org/licenses/bsd-license.php
// Contact: xbytor@gmail.com
//
//@show include
//
//@includepath "/c/Program Files/Adobe/xtools;/Developer/xtools"
//
//@include "xlib/XMPAliasInfo.jsx"
//@include "xlib/XMPConst.jsx"
//@include "xlib/XMPDateTime.jsx"
//@include "xlib/XMPFile.jsx"
//@include "xlib/XMPFileInfo.jsx"
//@include "xlib/XMPIterator.jsx"
//@include "xlib/XMPMeta.jsx"
//@include "xlib/XMPPacketInfo.jsx"
//@include "xlib/XMPProperty.jsx"
//@include "xlib/XMPUtils.jsx"
//
//@include "xlib/XMPData.jsx"
//

"XMPScript.jsx";
// EOF
