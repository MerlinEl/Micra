import os
os.environ['TESTING'] = '123'