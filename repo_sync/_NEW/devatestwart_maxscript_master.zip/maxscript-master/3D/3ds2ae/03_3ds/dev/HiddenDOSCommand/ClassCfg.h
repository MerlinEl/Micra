/*	ClassCfg.h - local class & generic configuration file for MAXScript SDK plugins
*
*  This is an empty file, I don't actually exposed a class 
*  biddle 2005
*/

// local root Value class for this plug-in
#define MS_LOCAL_ROOT_CLASS		

// local Generic function class
#define MS_LOCAL_GENERIC_CLASS	
