/*
comp=app.project.activeItem
comp.layers[1].parent=comp.layers.byName('Plane12')
*/
a=485
b=250
alert(a%b)