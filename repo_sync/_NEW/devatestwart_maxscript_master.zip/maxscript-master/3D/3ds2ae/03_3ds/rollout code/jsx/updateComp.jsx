// update comp
updateComp(%,%,%,%) //w,h,p,f

