//var xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
path='E:/03_Scripting/3ds2ae/04_ae/0 - xml/doc.xml'
f=File(path)
f//.open('r')
//str=File(path).read()
alert(f.fsName)