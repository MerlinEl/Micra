/*
comp=app.project.activeItem
layer=comp.layer(1)
*/
/*
//alert(obj.pointOfInterest.propertyGroup().name)
//comp.layers.addLight("New Light", [100,100])

prop=layer.rotation
prop=layer.orientation
//prop.setValue([45,45,45])
//alert(String(prop.propertyValueType))
//alert(prop.name)

//alert(app.project.item(1).layer(1).property('rotation').propertyValueType)

*/
//alert(String(PropertyValueType.NO_VALUE))
//layer=comp.layers.addSolid(obj.color, obj.name, obj.width, obj.height, 1)

//layer=comp.layers.addSolid([0.5,0.75,0.35879], "test", 100, 100, 1)



//f=File.openDialog()

//alert(app.project.items[Comp 1])
//alert(comp.layers.length)
//comp.layers[11].anchorPoint.setValue([-50,-50,0])
//app.project.libraryComp="hello"


/*
// declare array
	var arr = new Array()
	
// create 100 new arrays in the original array...
	for(x=0;x<100;x++){
		arr[x]=new Array()
	// then, for each of these new arrays, assign alements... 
		for(y=0;y<100;y++){
			arr[x][y]='Element: '+x+', Sub-element: '+y
			}
		}

alert(arr[20][75])
*/
/*
app.project.activeItem.time=2
str=app.project.activeItem.time
alert(str)
*/
//

c=app.project.items.addComp('movement 1', 200, 100, 1, 500, 25)