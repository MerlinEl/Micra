
How it works
� Just drag n drop the .ms file into the 3DS Max viewport

� Or drag n drop the .mzp file into the 3DS Max viewport, and then in Customize > Customize user interface, you'll find this script under the N00BY category

� Select an object then click "Preview"

� Adjust the number of slices you want or the distance between them

� Set the axis along which you want to slice the object by clicking the "X", "Y" or "Z" button

� Then click "Accept"