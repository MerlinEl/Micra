var namespace_test_project_1_1_properties =
[
    [ "Resources", "class_test_project_1_1_properties_1_1_resources.html", "class_test_project_1_1_properties_1_1_resources" ]
];