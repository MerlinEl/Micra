var classmm_max_controls_1_1_check_button =
[
    [ "UpdateColors", "classmm_max_controls_1_1_check_button.html#a9dd23db8c57fcc8bba15ee3c74b5c6a1", null ],
    [ "FrameOnMouseOverOnly", "classmm_max_controls_1_1_check_button.html#a80d565aa83a7ffb787b4f7e9d56c6af9", null ],
    [ "ShowFocusFrame", "classmm_max_controls_1_1_check_button.html#a8d76993c8100454d22e71a0bb5afd213", null ]
];