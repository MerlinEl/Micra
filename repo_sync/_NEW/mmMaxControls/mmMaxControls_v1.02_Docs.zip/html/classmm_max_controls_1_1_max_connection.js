var classmm_max_controls_1_1_max_connection =
[
    [ "DisableAccelerators", "classmm_max_controls_1_1_max_connection.html#acfb0c877ddebd95502fe7eb8ab688ddb", null ],
    [ "DrawFrame", "classmm_max_controls_1_1_max_connection.html#ac05718b0f77b638a0864d06c603d4f8b", null ],
    [ "EnableAccelerators", "classmm_max_controls_1_1_max_connection.html#a638816cd4e78f2ab3dc5adb6609b7ceb", null ],
    [ "RegisterControl", "classmm_max_controls_1_1_max_connection.html#a58d53428d1c675830a61bc9f85d47115", null ],
    [ "UnregisterControl", "classmm_max_controls_1_1_max_connection.html#ae1d30a3003e8b7697854102dd35d1b18", null ],
    [ "Instance", "classmm_max_controls_1_1_max_connection.html#a586c454796fd26c83586aaf5f058c6be", null ]
];