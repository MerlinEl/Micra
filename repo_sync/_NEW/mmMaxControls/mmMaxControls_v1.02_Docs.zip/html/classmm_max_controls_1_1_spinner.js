var classmm_max_controls_1_1_spinner =
[
    [ "Clear", "classmm_max_controls_1_1_spinner.html#a6978a42a9c1e44ba16b5a16df2b80baf", null ],
    [ "ResetValue", "classmm_max_controls_1_1_spinner.html#aac2687adb480e0e076aa303877996080", null ],
    [ "UpdateColors", "classmm_max_controls_1_1_spinner.html#aea1bb0d79e8f0d7aaa37c0cc63ec8f9e", null ],
    [ "DecimalPlaces", "classmm_max_controls_1_1_spinner.html#acf19e7576bb91ede9e76b532d8461b87", null ],
    [ "DefaultValue", "classmm_max_controls_1_1_spinner.html#aa6b0db3110e61a4d860dec5ccd105725", null ],
    [ "FloatValue", "classmm_max_controls_1_1_spinner.html#a7df604597b68847803b08afdda013d67", null ],
    [ "Increment", "classmm_max_controls_1_1_spinner.html#a392d19ae6209370626e041b246f1d3cc", null ],
    [ "IntValue", "classmm_max_controls_1_1_spinner.html#ab8094822f88c5246ff6d2e2e364c97e7", null ],
    [ "Maximum", "classmm_max_controls_1_1_spinner.html#aa7708c2c1e50e0a6658c5169155d235c", null ],
    [ "Minimum", "classmm_max_controls_1_1_spinner.html#a3544187aabbc0cf0fe3fc718bcfb9cdf", null ],
    [ "Value", "classmm_max_controls_1_1_spinner.html#a3eea139ac841f3ea866b22432818f2ba", null ],
    [ "ButtonDown", "classmm_max_controls_1_1_spinner.html#aebb02d269165cb4c4ee7fa91c0e9c4db", null ],
    [ "ButtonUp", "classmm_max_controls_1_1_spinner.html#afda4b759177641118ea85b8016184029", null ],
    [ "ValueChanged", "classmm_max_controls_1_1_spinner.html#a553746a3a799a88d98be6cd08f28d5c9", null ]
];