var class_test_project_1_1_properties_1_1_resources =
[
    [ "Culture", "class_test_project_1_1_properties_1_1_resources.html#ac5e4fdcda9be3d1ceecb7f2b5abc7313", null ],
    [ "ResourceManager", "class_test_project_1_1_properties_1_1_resources.html#acd3eb1c71699bcf31b22dc1b0df7cc01", null ]
];