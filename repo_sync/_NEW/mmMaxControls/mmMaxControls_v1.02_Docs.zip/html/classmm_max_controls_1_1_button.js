var classmm_max_controls_1_1_button =
[
    [ "UpdateColors", "classmm_max_controls_1_1_button.html#acde0ffbf4c93c16f9581eccf57e1b9ce", null ],
    [ "FrameOnMouseOverOnly", "classmm_max_controls_1_1_button.html#ab8ea1397b989bff13f7b3c1b7de525f3", null ]
];