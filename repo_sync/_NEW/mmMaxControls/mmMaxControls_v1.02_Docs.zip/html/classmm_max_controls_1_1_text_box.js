var classmm_max_controls_1_1_text_box =
[
    [ "UpdateColors", "classmm_max_controls_1_1_text_box.html#a452f141bb5351c72143092cc9beaa5f9", null ]
];