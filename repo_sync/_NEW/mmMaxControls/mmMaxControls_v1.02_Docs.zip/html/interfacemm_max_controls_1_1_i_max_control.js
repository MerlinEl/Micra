var interfacemm_max_controls_1_1_i_max_control =
[
    [ "UpdateColors", "interfacemm_max_controls_1_1_i_max_control.html#ae65514a5101ea6ac0785745f35975d36", null ]
];