var classmm_max_controls_1_1_spinner_button_event_args =
[
    [ "SpinCancelled", "classmm_max_controls_1_1_spinner_button_event_args.html#a68cc5fa156501355a46dad5455bcc88e", null ]
];