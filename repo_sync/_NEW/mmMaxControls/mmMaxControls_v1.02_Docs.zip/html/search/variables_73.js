var searchData=
[
  ['spincancelled',['SpinCancelled',['../classmm_max_controls_1_1_spinner_button_event_args.html#a68cc5fa156501355a46dad5455bcc88e',1,'mmMaxControls::SpinnerButtonEventArgs']]]
];
