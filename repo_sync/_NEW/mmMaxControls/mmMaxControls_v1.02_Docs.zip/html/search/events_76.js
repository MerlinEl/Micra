var searchData=
[
  ['valuechanged',['ValueChanged',['../classmm_max_controls_1_1_spinner.html#a553746a3a799a88d98be6cd08f28d5c9',1,'mmMaxControls::Spinner']]]
];
