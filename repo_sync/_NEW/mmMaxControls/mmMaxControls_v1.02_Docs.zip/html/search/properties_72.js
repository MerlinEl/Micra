var searchData=
[
  ['resourcemanager',['ResourceManager',['../class_test_project_1_1_properties_1_1_resources.html#acd3eb1c71699bcf31b22dc1b0df7cc01',1,'TestProject::Properties::Resources']]]
];
