var searchData=
[
  ['decimalplaces',['DecimalPlaces',['../classmm_max_controls_1_1_spinner.html#acf19e7576bb91ede9e76b532d8461b87',1,'mmMaxControls::Spinner']]],
  ['defaultvalue',['DefaultValue',['../classmm_max_controls_1_1_spinner.html#aa6b0db3110e61a4d860dec5ccd105725',1,'mmMaxControls::Spinner']]]
];
