var searchData=
[
  ['registercontrol',['RegisterControl',['../classmm_max_controls_1_1_max_connection.html#a58d53428d1c675830a61bc9f85d47115',1,'mmMaxControls::MaxConnection']]],
  ['resetvalue',['ResetValue',['../classmm_max_controls_1_1_spinner.html#aac2687adb480e0e076aa303877996080',1,'mmMaxControls::Spinner']]]
];
