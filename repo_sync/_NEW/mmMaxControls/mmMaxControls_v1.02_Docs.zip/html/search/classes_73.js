var searchData=
[
  ['spinner',['Spinner',['../classmm_max_controls_1_1_spinner.html',1,'mmMaxControls']]],
  ['spinnerbuttoneventargs',['SpinnerButtonEventArgs',['../classmm_max_controls_1_1_spinner_button_event_args.html',1,'mmMaxControls']]]
];
