
!!! WARNING, THIS SOFTWARE IS STILL IN BETA !!!

INSTALLATION INSTRUCTIONS:
--------------------------------------

Copy both dll files to C:\Program Files\Autodesk\MAXINSTALLDIR\bin\assemblies 

Open 3ds Max and navigate to: Customise > Customise User Interface.
Nested Layer Manager is available under the category 'Nested Layer Manager'
Open Nested Layer Manager is the windowed version.
Open Nested Layer Manager Dockable is the dockable version.


UNINSTALLATION INSTRUCTIONS:
--------------------------------------

Simply delete both dll files (ObjectListView.dll and NestedLayerManager.dll)


INFO:
--------------------------------------

Nested Layer Manager is written by Tim Hawker.
Please contact me at tim@timsportfolio.co.uk.

Nested Layer Manager utilises the fantastic ObjectListView control.
ObjectListView is available under the GPLv3 license, however a commercial 
license will be purchased for the final version of Nested Layer Manager.

All content copyright 2014 Tim Hawker.
Any trade names or logos shown are the trademarks of their respective owners.
