Nested Layer Manager 2 provides the ability to nest layers in 3ds Max. This tool is small, fast and allows layers to be nested in an unlimited number of folders.

!!! WARNING, THIS SOFTWARE IS STILL IN BETA !!!

INSTALLATION INSTRUCTIONS:
--------------------------------------

Copy both dll files from \NestedLayerManager\bin to C:\Program Files\Autodesk\MAXINSTALLDIR\bin\assemblies 

Open 3ds Max and navigate to: Customise > Customise User Interface.
Nested Layer Manager is available under the category 'Nested Layer Manager'
Open Nested Layer Manager is the windowed version.
Open Nested Layer Manager Dockable is the dockable version.


UNINSTALLATION INSTRUCTIONS:
--------------------------------------

Simply delete both dll files (ObjectListView.dll and NestedLayerManager.dll)


INFO:
--------------------------------------

Copyright 2016 Tim Hawker.
Nested Layer Manager 3 is Licensed under MIT license. 
ObjectListView is licensed under GPLv3.
Any trade names or logos shown are the trademarks of their respective owners.
