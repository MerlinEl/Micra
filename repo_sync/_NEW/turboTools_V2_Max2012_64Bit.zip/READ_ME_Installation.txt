Created by: Matt Lichy October 2012



turboTools V.2.8



--Note:  IF UPDATING AN OLDER VERSION, run the Un-Install first, then Install. 

--If you get an error about Windows Permissions or anything along that line, you have to rightclick on your max folder, and set the persmissions to allow all for your current username.  (look at included image)


Un-Installation:
---------------------------------

1. If max isn't running, open Max

2. Drag/Drop the supplied .mzp into the viewport.

3. If the Bitmap Collector Tool has been opened already, restart max first, then run the Uninstall-Install

4. Click Un-install.  The Un-installer should find something like 50+ files.  Accept the un-install.

5. Proceed to install...


Installation:

----------------------------------



 To install this tool follow these steps..
 

1.   While Max is running, Drag the supplied .MZP into your viewport.

2.  Click on Install, and wait for the tool to be installed.

3.  Go up to Customize -> Customize User Interface.

4.  From there you can Shortcut the toolbar or Drag/Drop the icon , found under the Category -> turbo_tools.



That's it!  :)




 