-- WkDevTool
------------

	This script for 3dsMax is a full development environment for Maxscript.	
	
	Learn more about this script here: http://werwackfx.com/index.php/graphictools/maxscript-main/maxscript-articles/72-wkdevtool
	
	3dsMax Supported Versions:	2015.x and higher
	Author:  Werwack
	Contact: werwack@werwackfx.com
	Website: http://werwackfx.com
	Copyright: Werwack
	
	
-- Install:
-----------

	Drag and drop WkDevTool.mzp inside one of the 3D viewports of 3dsMax.
	A popup dialog box will appear. Just follow the instructions.

	
	