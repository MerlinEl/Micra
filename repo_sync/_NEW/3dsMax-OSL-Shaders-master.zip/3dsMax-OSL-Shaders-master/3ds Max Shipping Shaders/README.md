### 3ds Max Shipping

The shaders shipping with the current version of max, and updates to them. 
The intent of this folder is that it should be safe to replace your 3dsmax\OSL 
folder with the content from here. It should only contain safe (compatible)
updates to the shaders shipping together with max.

