### Stable

These are shaders that are mature enough and stable enough that the intent is that
the shaders interface and behaviour won't substantially change in the future. It may
gain parameters, but defaults should be compatible with the previous version. These 
shaders are candidates to be included in the shipping set in the next version.
