﻿using System.Windows.Forms;

namespace CircularProgressBarSample
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
    }
}