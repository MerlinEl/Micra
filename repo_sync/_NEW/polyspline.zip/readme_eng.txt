Macroscript PolySpline v3.0 for 3dsmax 2009 (also works in 3dsmax 5.1, 6, 7, 8, 9, 2008)

Helps to draw a spline, like a AutoCAD Polyline tool by free or precisely coordinates, but works faster.

Syntax of the coordinate input is the same as AutoCAD Command Line.

The user type coords in the MAXScript Listener Window (press F11 to open it).


New features:
1. Correct button-trigger to turn script on or off.
2. Freehand mode to draw splines by hand on XY-plane or surface of the Base-object (Hotkey F).


Installation:

1. Copy PolySpline_v3.0.mcr and PolySpline_v3.0.mse to max folder \UI\MacroScripts.
2. Copy files from folder "Icons" to max folder UI\Icons.
3. Run 3dsmax, go to Customize\Customize User Interface\Toolbars, and create new toolbar.
4. Select "Scriptattack" from Category list and drag label "PolySpline v3.0" to your toolbar. The button will be created there.
If you wish, you may drag the label to any standart toolbar without creating you own toolbar.

Thats all, PolySpline is ready to work.


PolySpline features:

1. To draw orthogonal or polar line to precisely distance, leave mouse cursor in required direction, type distance value, press Enter (in Ortho or Polar mode).

2. All hotkeys below work only if MAXScript Listener Window active.

3. To set Base-object to draw on when Freehand mode active, select single object and press B.

4. F button turns on Freehand mode. If you continue old spline with freehand then script weld splines, otherwise freehand spline will be independent object.

5. O button turns Ortho mode to ON or OFF state.

6. P button turns Polar Snap mode to ON or OFF state or changes the vector to snap on.

7. Press P to change Polar Snap Mode. Polar Snap works relative to X Axis or previous segment or tangent if the segment is the part of the arc.

8. Press S to open or close Polar Snap Settings rollout.

9. To start Arc press A.

10. To point the Center of the Arc press C (Ortho mode automatically turnes off). Press E, if you don't wish to point center.

11. Right click to remove previous vertex. If the previous segment is a curve then the clicking cancels tangent feature but don't deletes the vertex. To delete vertex right click again. If PolySpline in Arc drawing mode then right click to cancel it. Hotkey O does not work when tangent drawing mode is on. Hotkey P does not work when tangent drawing mode is on.

12. Press [, ] and I buttons to zoom and pan.

13. E button turns Extend mode on

14. T button turns Trim mode on

15. ESC button finishes the drawing and asks is the spline must be closed or not.




The user can enter coordinates in one of several forms (based on the command line input syntax for AutoCAD), as follows (from chapter "Picking Points in the Viewports" of the MAXScript Reference):

x, y, z or [x, y, z]

explicit point in current construction plane coordinates

x, y or [x, y]

point on the construction plane (cp)

d

point d units away in mouse direction from last point

@ x, y, z or @[x, y, z]

relative, offset to last input point

@ x, y or @[x, y]

on cp, relative to last point's projection on cp

d < a

polar on cp, distance from cp origin at a angle from x-axis

@ d < a

relative polar on cp, centered on last point

d < a1 < a2

spherical on cp, d from cp origin at a1 from x and a2 angle from xy-plane

@ d < a1 < a2

relative spherical

There can be zero or more white space characters before and between numbers and metacharacters.

These typed-coordinates are interpreted as relative to the current active grid construction plane and the coordinates returned by pickPoint() are always in world-space.


_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

If you find any errors in PolySpline, please mail to building-building@yandex.ru

Enjoy now, while PolySpline is freeware			1acc