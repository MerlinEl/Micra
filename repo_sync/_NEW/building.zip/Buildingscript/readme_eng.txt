Script Building v1.2 for 3dsmax 2008 (also works in 3dsmax 5.1, 6, 7, 8, 9)

Creates geometry of the walls based on planar (Z is same for all points) broken line (boundary).
The interface is simple, clear and comfortable. The user can easily manipulate all geometry within very accurate precision.


Installation:
 1. Copy all files to max folder \Scripts\Buildingscript.
 2. Utilities Panel > MAXScript > Run Script
 3. Find and open Building.ms
 6. In the Utilities dropdownlist select Building v1.2


Workflow:

Script rollouts arranged in order of creation of the geometry:
1. Unit and Boundary
2. Wals and Storeys
3. Doorways, Window Openings
4. Meshes and Materials

Overall goals:
 Step 1: Draw any spline.
 Step 2: Press button "Pick Boundary or Element" of the "Unit and Boundary" rollout and pick your spline.
 Step 3: In "Wals and Storeys" rollout set the heights of the walls, quantity and heights of the storeys.
 Step 4: By "Doorways, Window Openings" rollout create and edit apertures of necessary walls.
 Step 5: Rollout "Meshes and Materials" converts splines to 3D-Meshes and welds the corners between walls.

Screenshot of the interface: http://www.scriptattack.com/images/building_shot_eng.gif
Video-demonstration of the workflow: http://www.scriptattack.com/images/buildingdemo.avi


Known bug: sometimes when you run the script at first time, the spline may collapse after you pick it with "Pick Boundary or Element" button. In this case run the script again. Keep the checkbox "Create a copy of Boundary" checked to save your spline.


Advices:

Script knows any created geometry (only at the current 3ds max session).
You can turn back to any building - just make it current by selecting any element with "Pick Boundary or Element" button and corresponding parameters will be updated in the rollouts.

You can not "undo" the script actions, therefore i recomend to make a copy of a boundary spline before picking it.

It is not recomended to delete, hide or rename objects that were created by the script, because it "calls" them by names.
Anyway, the work of the script will not be broken, even if you did this.

After you created 3d-model it will be completely selected, you can invert selection and delete any other additional objects (grids and splines).

Before you will create 3d-model, you can edit splines manually to make unrectangular wall for example.


List of the abbreviations in object names:

_Unit - current building Unit.
_Boundary � edited Boundary of the walls.
_Grid_Boundary � Grid-object (grid was created in the plane of the boundary).
_GridWall � Grid-object (grids were created in the plane of the every wall).
_W � Wall.
_S � Storey. Storey is an object with the length equal to wall length but different height. Every wall can be divided to storeys.
_L � Level of the apertures (Window Openings or Doorways).
_awo � Aperture Window Opening spline.
_adw � Aperture Doorway spline.
_M � complete 3d-model of any building object (Mesh).

Example: Unit1_W4_S5_L1_awo03 � the name of the third Aperture Window Opening spline in the first level at fifth storey
of the fourth wall in the Unit number 1.


----------------------------

Most popular questions and answers:

Q: How to bring back standart Home Grid?
A: Views Menu> Grids > Activate Home Grid.

Q: Why nothing happens, when I change the height of the Storey?
A: Because it is the top Storey at the Wall. To change height of it, you have to change the height of the Wall.

Q: Why nothing happens, when I create Levels?
A: You wrong, it happens in a right way, but to see it you have to increase width and height of the element (those parameters too small by default).

Q: Why nothing happens, when I create a new Level?
A: Because new levels were created with the parameters of the previous level. Change some parameters to see it.

Q: How to edit meshes that were created?
A: Remove them, edit splines and create meshes again.

Q: Can I work with some buildings simultaneously?
A: Yes, just press "Pick Boundary or Element" button and pick any object of the any other Building.

Q: I want to spread levels on all walls and storeys, I have to click on every object to do this?
A: No, you even may select all by region, script can make out the objects to apply spreading by itself.

Q: Levels moved out of the wall limits after spreading. How to fix this?
A: Change any parameter of the level (for example spacing or position) and all elements will take correct place.

Q: When I changed the arc-height of the arched aperture the aperture was distorted.
A: Don't play with this parameter too much time. Turn aperture to rectangular, then turn back to arched.

Q: There are too many unnecessary objects at the end of the work, how to remove them fast?
A: Select Objects > List Types > Shapes � Helpers > Invert > All> Select > Delete

Q: Can I create Building, save scene, close 3ds max and then turn back to this Building by script?
A: No. Script works only at current 3ds max seccion. May be I'll include the ability to load and save units in the future versions of the script.


-----------------------------

Any messages concerned with the script Building v1.2 you can mail to building-building@yandex.ru				1acc