# This module can be accessed by a python controller with
# its execution method set to 'Module'
# * Set the module string to "gamelogic_module.main" (without quotes)
# * When renaming the script it MUST have a .py extension
# * External text modules are supported as long as they are at
#   the same location as the blendfile or one of its libraries.

import bge
import TCPServer.server as Server
import TCPServer.client as Client

# variables defined here will only be set once when the
# module is first imported. Set object specific vars
# inside the function if you intend to use the module
# with multiple objects.


def main(cont):
	own = cont.owner

	# If the server is running, give it a chance to update
	if Server.server is not None:
		Server.server.run()

def startServer(cont):
	
	if cont.sensors['start_server'].positive == False:
		return
	
	print("Starting server...")
	
	# Create a new TCP socket server
	Server.server = Server.Server()
	Server.server.startServer(9090)

def clientRun(cont):
	"""Called once a frame to see if the client has action to do."""
	
	own = cont.owner
	
	if 'client' not in own:
		return
		
	# Access the client
	client = own['client']
	if client is None:
		return;
		
	if client.isDone == False:
		client.update()
		if client.isDone:
			own['client'] = None
			
def startClient(cont):
	
	own = cont.owner
	if cont.sensors['start_client'].positive == False:
		return;
		
	own['client'] = Client.Client()
	own['client'].send('localhost', 9090, "Test Message")