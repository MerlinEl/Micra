import socket
import errno

class ServerClient:
    """Tracks client connections on the server side."""
    
    # The socket connection to the client
    #   clientSocket = None

    # 'static' id for tracking client connections
    nextId = 1

    def __init__(self, socket):
        self.clientSocket = socket
        self.id = ServerClient.nextId
        ServerClient.nextId = ServerClient.nextId + 1

    def update(self):
        """Called to let the client check for activity.  Returns True if the connection is still good.  False if the connection is closed."""

        try:
            data = self.clientSocket.recv(4096)
            if len(data) != 0:
                print("client %d: %s"%(self.id, data))
            else:
                # Reads of 0 length mean the client closed the connection
                self.clientSocket.close()
                self.clientSocket = None
                return False
                
        except socket.error as err:

            # Any exception but 'would block' will close the socket
            if err.errno != errno.EWOULDBLOCK:
                print("Socket error %d %s"%(err.errno, err.strerror))
                self.clientSocket.close()
                self.clientSocket = None;
                return False
        
        return True

class Server:
    
    # No construction for now
    def __init__(self):
        self.clients = []
        self.listenSocket = None
        pass

    def startServer(self, port):
        """Starts the server on the given port."""
        
        # Create a non-blocking socket
        self.listenSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.listenSocket.setblocking(0)

        # Bind to the given port.
        self.listenSocket.bind( ('localhost', port) )
        self.listenSocket.listen(5)

    def run(self):
        """Call to check for non-blocking operations."""

        # Ensure the server is running
        if self.listenSocket is None:
            return

        clientSocket = None
        try:
            clientSocket, addr = self.listenSocket.accept()
            clientSocket.setblocking(0)
        except socket.error as err:
            # Any error but "Would block" should cause the socket to close
            if err.errno != errno.EWOULDBLOCK:
                self.listenSocket.close()
                self.listenSocket = None
                return
        
        # If there is a new client connection, start tracking it
        if clientSocket is not None:
            # Wrap the raw socket in an object that can track
            # other aspects of the client connection
            serverClient = ServerClient(clientSocket)
        
            # Track this list of clients
            self.clients.append(serverClient);

        # See if there is activity on the client connections
        closedClients = []
        for client in self.clients:
            clientOk = client.update()
            if clientOk == False:
                closedClients.append(client)

        # Remove any clients that have closed
        for client in closedClients:
            self.clients.remove(client)

        if len(closedClients) != 0:
            print("Client closed.  Currently connected clients: %d"%(len(self.clients)))

# Global server object
server = None

