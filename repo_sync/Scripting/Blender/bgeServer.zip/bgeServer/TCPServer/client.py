import socket
import errno

class Client:
    """Represents a client connection to a server."""

    def __init__(self):
        """Do nothing for now."""
        self.clientSocket = None
        self.sendBuffer = None
        self.isDone = False
        pass

    def send(self, host, port, message):
        """Connects the client to the given host+port and sends the supplied message."""

        print("Entering send")

        # Create a non-blocking socket
        self.clientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.clientSocket.setblocking(0)

        # Attempt to connect to the server
        try:
            self.clientSocket.connect( (host, port) )
        except socket.error as err:
            if err.errno != errno.EWOULDBLOCK and err.errno != errno.EINPROGRESS:
                print("Socket error %d %s"%(err.errno, err.strerror))
                self.isDone = True
                self.clientSocket.close()
                self.clientSocket = None
                return

        self.isDone = False;
        self.sendBuffer = message

    def update(self):
        """Called peridically to see if an operation can be done on a socket."""

        # See if all the work is done
        if self.clientSocket is None or self.isDone == True:
            return

        # Try to send the message
        try:
            numMoved = self.clientSocket.send(bytes(self.sendBuffer,'UTF-8'))
            if numMoved == len(self.sendBuffer):
                self.isDone = True
                self.clientSocket.close()
                self.clientSocket = None;
                self.sendBuffer = None
                return

        except socket.error as err:
            # Any error but 'would block' will close the connection
            if err.errno != errno.EWOULDBLOCK:
                print("Socket error %d %s"%(err.errno, err.strerror))
                self.isDone = True;
                self.clientSocket.close()
                self.clientSocket = None;
                self.sendBuffer = None
                return
    