Compiled commit f02b1ffda6e39f6e9ac6969b4bdce23e3e759581, downloaded from https://github.com/TheCrazyT/Scarlet/
Binaries located at: https://bintray.com/thecrazyt/Scarlet/Scarlet/0.9#files/0.9