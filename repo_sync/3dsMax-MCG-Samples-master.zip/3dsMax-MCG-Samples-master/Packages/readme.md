# Downloading Max Creation Graph Tools Directly

1. Choose from the list of packages at: https://github.com/ADN-DevTech/3dsMax-MCG-Samples/tree/master/Packages

2. Click on the .mcg link. For example:
https://github.com/ADN-DevTech/3dsMax-MCG-Samples/blob/master/Packages/ArrowM.mcg

    Note: Do not download that file or "save target" it is an HTML file. 

5. From the package HTML page click the "download" button to download the actual MCG package. 
