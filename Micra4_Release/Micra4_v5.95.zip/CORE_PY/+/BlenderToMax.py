
#~ import [ test_obj_01.fbx ] in to Blender	
	#~ blender test.blend -P test.py
	
	
#~ import pymxs
#~ from pymxs import runtime as rt
#~ myfile = 'C:\\Users\\avisd\\Desktop\\Sample+House.skp'
#~ rt.importFile(myfile, using=rt.sketchUp)

#~ https://help.autodesk.com/view/3DSMAX/2017/ENU/?guid=__py_ref_demo_materials_8py_example_html
#~ https://digitalrune.github.io/DigitalRune-Documentation/html/6f749972-9cb2-4274-b283-c327ba45e379.htm